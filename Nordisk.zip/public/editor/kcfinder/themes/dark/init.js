new Image().src = 'themes/dark/img/loading.gif'; // preload animated gif
