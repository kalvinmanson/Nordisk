<?php

namespace App\Http\Controllers;

use Auth;
use Carbon;
use Illuminate\Http\Request;
use App\Chat;
use App\User;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class ChatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('chats.index');
    }

    public function show($id)
    {
        $current_user = Auth::user();
        $chats = Chat::where('user_id', $current_user->id)->where('id', '>', $id)->get();
        return $chats->load('user')->toJson();
    }
    public function store(Request $request)
    {
        $current_user = Auth::user();

        $record_store = request()->all();
        $record_store['user_id'] = $current_user->id;
        Chat::create($record_store);
    }


    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Only Admins
        if(!$this->hasrole('Admin')) { return redirect('/'); }
    }
}
